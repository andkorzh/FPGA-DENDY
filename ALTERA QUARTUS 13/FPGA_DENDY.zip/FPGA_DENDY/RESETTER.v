module RESETTER(
input Clk,
input VSYNC,
output RESOUT
);
reg DET;
reg RS_FF;
reg [5:0]CNT;

wire DET_OUT;
assign DET_OUT = ~DET & VSYNC;

assign RESOUT = &CNT[4:0];

always @(posedge Clk)begin
                     DET <= VSYNC;
                  if( DET_OUT ) CNT[5:0] <= CNT[5:0] + 1'b1;
             else if( RS_FF   ) CNT[5:0] <= 6'h00;
                  if( CNT[5:0] == 6'h1F ) RS_FF <= 1'b1;
             else if( CNT[5:0] == 6'h3F ) RS_FF <= 1'b0;
                      end
endmodule