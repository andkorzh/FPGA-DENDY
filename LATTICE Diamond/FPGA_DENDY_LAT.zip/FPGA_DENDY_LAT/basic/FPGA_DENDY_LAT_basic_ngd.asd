[ActiveSupport NGD]
