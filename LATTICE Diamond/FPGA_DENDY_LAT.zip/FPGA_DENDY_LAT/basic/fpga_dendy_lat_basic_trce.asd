[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 65.937 MHz (42.954 MHz);
Fmax_1 = 27.598 MHz (21.477 MHz);
Fmax_2 = - (-);
Failed = 0 (Total 3);
Clock_ports = 2;
Clock_nets = 3;
; Hold Analysis
Fmax_0 = 0.219 ns (0.000 ns);
Fmax_1 = 0.260 ns (0.000 ns);
Fmax_2 = - (-);
Failed = 0 (Total 3);
Clock_ports = 2;
Clock_nets = 3;
