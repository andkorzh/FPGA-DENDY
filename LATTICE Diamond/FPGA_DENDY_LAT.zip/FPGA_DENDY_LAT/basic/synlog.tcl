run_tcl -fg FPGA_DENDY_LAT_basic_synplify.tcl
