/*
 ===============================================================================================
 *                              Copyright (C) 2026 andkorzh
 *
 *
 *                This program is free software; you can redistribute it and/or
 *                modify it under the terms of the GNU General Public License
 *                as published by the Free Software Foundation; either version 2
 *                of the License, or (at your option) any later version.
 *
 *                This program is distributed in the hope that it will be useful,
 *                but WITHOUT ANY WARRANTY; without even the implied warranty of
 *                MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *                GNU General Public License for more details.
 *
 *                      FPGA  DENDY  LATTICE (LCMXO2-4000HC-4TG144C)
 *
 *   This design is inspired by Wiki BREAKNES. I tried to replicate the design of the real
 * NMOS processor MOS 6502 as much as possible. The Logsim 6502 model was taken as the basis
 * for the design of the circuit diagram
 *
 *  author andkorzh
 *  Thanks:
 *      HardWareMan: author of the concept of synchronously core NES PPU, help & support.
 *
 *      Org (ogamespec): help & support, C++ Cycle accurate model NES, Author: Wiki BREAKNES
 *          
 *      Nukeykt: help & support
 *
 ===============================================================================================
*/

module FPGA_DENDY_LAT(
// Clocks
input N_CLK,           // Clock 14.318 MHz for NTSC
input P_CLK,           // Clock 17.734 MHz for PAL (DENDY)
// Inputs
input MODE_IN,         // PAL mode
input DENDY_IN,        // DENDY mode
input RES,             // Reset
input IRQ,             // Interrupt request input
input VRAMA10,         // VRAM Mirroring mode
input nVRAMCS,         // VRAM enble (CIRAM_CE)
input [2:0]PALSEL,     // RGB Palette select    
// Outputs
inout [7:0]DBUS,       // Data bus
output M2,             // M2 Cycle
output M2_out2,        // M2 Cycle for gamepad
output T1_6502,        // 6502 T1 Cycle
output RnW_EXT,        // Read/Write
output DB_DIR,         // DATA BUS LEVEL SHIFTER CONTROL
output reg nROMSEL,    // Cartridge ROM select
output [14:0]A,        // Address BUS
output [6:0]DMC,       // DMC output
output [5:0]So,        // SQA + SQB + TRIA + RND output
output [1:0]nIN,       // Read peripheral port ( $4017, $4016 )
output [2:0]OUT,       // Write peripheral port $4016
output nRD,            // VRAM (CHR ROM) Read Strobe
output nWR,            // VRAM          Write Strobe
output ALE,            // ALE VRAM Address Low Byte Latch Strobe Output
output PD_DIR,         // PD BUS LEVEL SHIFTER CONTROL
inout  [7:0]PD_BUS,    // PPU Graphics Data Bus Input
output [13:8]PA,       // WRAM (CHR ROM) Address
output [17:0]RGB,      // RGB output R6 + G6 + B6
output [2:0]EMPH,      // EMPHASIS R G B
output [6:0]COMPOSIT,  // Composite video output  
output SYNC            // Composite sync output
);

// Module connections
wire Clk;
wire Clk2;
wire PAL;
wire [15:0]ADR;
wire [3:0]SQA;
wire [3:0]SQB;
wire [3:0]RND;
wire [3:0]TRIA;
wire RnW;
wire PPU_INT;
wire [13:0]PAo;
wire HSYNC;
wire VSYNC;
wire SUBCLK;
wire nR4015;

// Variables
reg nWRAMCS, nPPU_CE;
reg [7:0]ALE_REG;

// Combinatorics
assign A[14:0] = ADR[14:0];
assign DB_DIR = nR4015 & nWRAMCS & nPPU_CE & RnW;
assign RnW_EXT = RnW;
assign M2_out2 = M2;
assign PAL =  ~MODE_IN | ~DENDY_IN;

// PLL
PLL MOD_PLL(
N_CLK, 
P_CLK, 
PAL, 
Clk2,
Clk
);

// APU
RP2A03 MOD_RP2A03(
Clk2,
~MODE_IN,
~DENDY_IN,
~PPU_INT,
IRQ,
~RES,
DBUS[7:0],
ADR[15:0],
RnW,
M2,
T1_6502,
SQA[3:0],
SQB[3:0],
RND[3:0],
TRIA[3:0],
DMC[6:0],
So[5:0],
OUT[2:0],
nIN[1:0],
nR4015
);


wire [7:0]WRAMBUS;
//WRAM
//         Clk, ClkEn, Res,   WE,                Address, Data,            Q
SRAM WRAM( Clk, 1'b1,  1'b0, ~( RnW | nWRAMCS ), A[10:0], DBUS[7:0],  WRAMBUS[7:0] );
// Outputting WRAM values ??to the data bus
assign DBUS[7:0] = ~( ~RnW | nWRAMCS ) ? WRAMBUS[7:0] : 8'hZZ;
//***************************************
// PPU
RP2C02 MOD_PPU(
Clk,
Clk2,
PAL,
~DENDY_IN,
1'b1,       // nRES
1'b1,       // ODDEVEN EN
PALSEL[0],    
PALSEL[1],
PALSEL[2],
RnW,        // RnW
nPPU_CE,    // nDBE
ADR[2:0],   // AB Bus
nVRAMCS ? PD_BUS[7:0] : VRAMBUS[7:0], // PD In
DBUS[7:0],
RGB[17:0],
EMPH[2:0],
PAo[13:0],
PPU_INT,    // INT
ALE,
nWR,
nRD,
SYNC,
HSYNC,
VSYNC,
COMPOSIT[6:0]
);


wire [7:0]VRAMBUS;
//VRAM
//         Clk, ClkEn, Res,         WE,                 Address,                        Data,         Q
SRAM VRAM( Clk, 1'b1,  1'b0, ~( nWR | nVRAMCS ), { VRAMA10, PAo[9:8], ALE_REG[7:0]}, PAo[7:0], VRAMBUS[7:0] );
//*************************
assign PD_BUS[7:0] = nRD ? PAo[7:0] : 8'hZZ;
assign PA[13:8]    = PAo[13:8];
assign PD_DIR = nRD;


always @(posedge Clk)begin
	            nROMSEL <= ~( M2 &  ADR[15] );
                nWRAMCS <=   ~M2 |  ADR[13] | ADR[14] | ADR[15];
                nPPU_CE <=   ~M2 | ~ADR[13] | ADR[14] | ADR[15];
                if (ALE) ALE_REG[7:0] <= PAo[7:0];  // ADDRESS LATCH for VRAM 
                      end
endmodule